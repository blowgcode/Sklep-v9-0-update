# Tpay OpenAPI library

Library for all methods available via OpenAPI [Tpay](https://openapi.tpay.com/).

[![Latest stable version](https://img.shields.io/packagist/v/tpay-com/tpay-openapi-php.svg?label=current%20version)](https://packagist.org/packages/tpay-com/tpay-openapi-php)
[![PHP version](https://img.shields.io/packagist/php-v/tpay-com/tpay-openapi-php.svg)](https://php.net)
[![License](https://img.shields.io/github/license/tpay-com/tpay-openapi-php.svg)](LICENSE)
[![CI status](https://github.com/tpay-com/tpay-openapi-php/actions/workflows/ci.yaml/badge.svg?branch=master)](https://github.com/tpay-com/tpay-openapi-php/actions)
[![Type coverage](https://shepherd.dev/github/tpay-com/tpay-openapi-php/coverage.svg)](https://shepherd.dev/github/tpay-com/tpay-openapi-php)

[Polish version :poland: wersja polska](./README_PL.md)

## Installation

Install via [Composer](https://getcomposer.org):
```console
composer require tpay-com/tpay-openapi-php
```

Install via [Git](https://git-scm.com) over SSH:
```console
git clone git@github.com:tpay-com/tpay-openapi-php.git
```

Install via [Git](https://git-scm.com) over HTTPS:
```php
git clone https://github.com/tpay-com/tpay-openapi-php.git
```

Manual download:
https://github.com/tpay-com/tpay-openapi-php/archive/master.zip

## Configuration

The only thing you need to do is to set your [OAuth](https://oauth.net) credentials like in example config file ([see example](examples/ExamplesConfig.php)).
You can generate access keys in [Tpay's merchant panel](https://panel.tpay.com).

The [`src/Loader.php`](src/Loader.php) file handles all required class loading, so you can include this file to any file you are editing.

All methods described in [Tpay OpenAPI documentation](https://openapi.tpay.com) can be easily executed by running one of the library methods like:
```php
$cache = new Cache(/** here you can inject your PSR6 or PSR16 cache storage object */);
$tpayApi = new TpayApi($cache,'12345-132123', '456');
$transactions = $tpayApi->Transactions->getTransactions();
```
##### Credentials

All currently available API methods have an example usage in [`Examples`](examples) directory.
You can obtain sandbox credentials by registering on https://register.sandbox.tpay.com/ website.

### Examples of usage

##### Frontend forms and payment handlers:

[Payment method choice form](examples/TransactionsApi/BankSelectionForm.php), [BLIK method form](examples/TransactionsApi/BlikPayment.php), [simple credit card form](examples/TransactionsApi/CardGate.php), [extended credit card form](examples/TransactionsApi/CardGateExtended.php), [recurrent payment example](examples/TransactionsApi/RecurrentPayment.php), [payment notification webhook](examples/Notifications/PaymentNotificationExample.php).

##### Merchant accounts registration (for partners only)

[Example of usages](examples/AccountsApi/AccountsApiExample.php).

## Logs

Library has own logging system to save all API calls, responses, webhook notifications, and exceptions.
Make sure that `Logs` directory is writable and add rule to Apache `.htaccess` or NGINX to deny access to this area from browser.
The log files are created for each day separately.

The logging is enabled by default, but you can disable this feature by command:
```php
Logger::disableLogging();
```

You can also set your own logging path by this command:
```php
Logger::setLogPath('/my/own/path/Logs/');
```
The logs file names will be assigned automatically.

You can replace the logging system above by setting up your own implementation of `Psr\Log\LoggerInterface` with:
```php
Logger::setLogger($logger);
```

## Custom templates and static files path

You can set your own templates path, so you can copy and modify the `phtml` template files from this library.
```php
Util::$customTemplateDirectory = '/my/own/templates/path/';
```

You can set your own static files path, so you can copy and modify the `css` and `js` files from this library. By default, the path is based on `$_SERVER['REQUEST_URI']` value.
```php
Util::$libraryPath = '/my/own/path/';
```

## Language

The library supports two languages (English and Polish). Default language is English.
Change language example:
```php
// Any time you construct the class providing payment forms, you can pass the language in constructor
$paymentForms = new PaymentForms('pl');
// After this line all static messages (input labels, buttons titles etc.) will be displayed in Polish

// If you want to access translations manually, use:
$lang = new Lang();
$lang->setLang('pl'); // for setting language
$lang->lang('pay'); // to echo translated key
```

## License

This library is released under the [MIT License](http://www.opensource.org/licenses/MIT).
