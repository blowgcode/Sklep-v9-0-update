<?php

namespace Tpay\OpenApi\Dictionary;

class NotificationsIP
{
    const SECURE_IPS = [
        '176.119.38.175',
        '195.149.229.109',
        '148.251.96.163',
        '178.32.201.77',
        '46.248.167.59',
        '46.29.19.106',
    ];
}
