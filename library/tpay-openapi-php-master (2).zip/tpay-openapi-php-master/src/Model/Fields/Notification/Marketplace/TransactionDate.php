<?php

namespace Tpay\OpenApi\Model\Fields\Notification\Marketplace;

use Tpay\OpenApi\Model\Fields\Field;

class TransactionDate extends Field
{
    protected $name = 'transactionDate';
    protected $type = self::STRING;
}
