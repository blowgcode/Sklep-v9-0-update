<?php

namespace Tpay\OpenApi\Model\Fields\Notification\Marketplace;

use Tpay\OpenApi\Model\Fields\Field;

class CardToken extends Field
{
    protected $name = 'cardToken';
    protected $type = self::STRING;
}
