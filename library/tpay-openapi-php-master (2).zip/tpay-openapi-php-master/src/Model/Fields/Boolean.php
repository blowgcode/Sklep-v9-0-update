<?php

namespace Tpay\OpenApi\Model\Fields;

class Boolean extends Field
{
    protected $name = __CLASS__;
    protected $type = self::BOOL;
}
