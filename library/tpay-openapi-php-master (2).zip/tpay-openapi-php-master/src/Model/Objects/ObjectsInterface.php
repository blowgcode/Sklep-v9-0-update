<?php

namespace Tpay\OpenApi\Model\Objects;

interface ObjectsInterface
{
    public function getRequiredFields();
}
