<?php

namespace Tpay\OpenApi\Model\Objects\Transactions;

use Tpay\OpenApi\Model\Fields\Address\City;
use Tpay\OpenApi\Model\Fields\Address\Phone;
use Tpay\OpenApi\Model\Fields\Address\PostalCode;
use Tpay\OpenApi\Model\Fields\Payer\Address;
use Tpay\OpenApi\Model\Fields\Payer\IP;
use Tpay\OpenApi\Model\Fields\Payer\Name;
use Tpay\OpenApi\Model\Fields\Payer\TaxId;
use Tpay\OpenApi\Model\Fields\Payer\UserAgent;
use Tpay\OpenApi\Model\Fields\Person\Email;
use Tpay\OpenApi\Model\Fields\Transaction\Country;
use Tpay\OpenApi\Model\Objects\Objects;

class Payer extends Objects
{
    const OBJECT_FIELDS = [
        'email' => Email::class,
        'name' => Name::class,
        'phone' => Phone::class,
        'address' => Address::class,
        'code' => PostalCode::class,
        'city' => City::class,
        'country' => Country::class,
        'taxId' => TaxId::class,
        'ip' => IP::class,
        'userAgent' => UserAgent::class,
    ];

    /** @var Email */
    public $email;

    /** @var Name */
    public $name;

    /** @var Phone */
    public $phone;

    /** @var Address */
    public $address;

    /** @var PostalCode */
    public $code;

    /** @var City */
    public $city;

    /** @var Country */
    public $country;

    /** @var TaxId */
    public $taxId;

    /** @var IP */
    public $ip;

    /** @var UserAgent */
    public $userAgent;

    public function getRequiredFields()
    {
        return [
            $this->email,
            $this->name,
        ];
    }
}
